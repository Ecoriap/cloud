<!DOCTYPE html>
<html>
<head>
	<title>MyEcoria | Faucet Valide</title>
	<link rel="stylesheet" type="text/css" href="css/faucet.css">
	<script src="https://js.hcaptcha.com/1/api.js" async defer></script>
	<link rel="icon" type="image/png" href="img/logo.png">

	<!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-VF7WYPMW94"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'G-VF7WYPMW94');
        </script>

</head>
<body>
	<div class="valide">
		</br>
		<img src="img/valide.png" width="100%" class="valideornot">
		</br>
	</div>
</body>
</html>
