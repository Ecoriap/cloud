<!DOCTYPE html>
<html>
<head>
	<title>MyEcoria | Faucet</title>
	<link rel="stylesheet" type="text/css" href="faucet.css">
	<script src="https://js.hcaptcha.com/1/api.js" async defer></script>
</head>
<body>
	<div class="valide">
		</br>
		<img src="images/invalide.png" width="100%" class="valideornot">
		</br>
	</div>
</body>
</html>
